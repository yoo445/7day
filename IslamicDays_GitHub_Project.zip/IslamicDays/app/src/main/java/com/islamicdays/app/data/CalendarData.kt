package com.islamicdays.app.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

enum class CalendarMode { HIJRI, GREGORIAN }

data class Settings(
    val language: String = "so",
    val calendarMode: CalendarMode = CalendarMode.HIJRI,
    val zoneId: String = "Africa/Mogadishu",
    val position: String = "Center",
    val scale: Float = 1f,
    val colorName: String = "Blue",
    val accent: Long = 0xFF1769E0,
    val fontName: String = "Default"
)

private val Context.dataStore by preferencesDataStore("islamic_days_settings")

class SettingsStore(private val context: Context) {
    private val lang = stringPreferencesKey("lang")
    private val mode = stringPreferencesKey("mode")
    private val zone = stringPreferencesKey("zone")
    private val position = stringPreferencesKey("position")
    private val scale = floatPreferencesKey("scale")
    private val color = stringPreferencesKey("color")
    private val accent = longPreferencesKey("accent")
    private val font = stringPreferencesKey("font")

    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        Settings(
            language = p[lang] ?: "so",
            calendarMode = runCatching { CalendarMode.valueOf(p[mode] ?: "HIJRI") }.getOrDefault(CalendarMode.HIJRI),
            zoneId = p[zone] ?: "Africa/Mogadishu",
            position = p[position] ?: "Center",
            scale = p[scale] ?: 1f,
            colorName = p[color] ?: "Blue",
            accent = p[accent] ?: 0xFF1769E0,
            fontName = p[font] ?: "Default"
        )
    )

    suspend fun save(s: Settings) {
        context.dataStore.edit { p ->
            p[lang] = s.language
            p[mode] = s.calendarMode.name
            p[zone] = s.zoneId
            p[position] = s.position
            p[scale] = s.scale
            p[color] = s.colorName
            p[accent] = s.accent
            p[font] = s.fontName
        }
    }
}

data class DayText(val arabic: String, val local: String) {
    companion object {
        fun forDate(date: LocalDate, language: String): DayText {
            return when (date.dayOfWeek.value) {
                1 -> DayText("الإثنين", if (language == "so") "Isniin" else "Monday")
                2 -> DayText("الثلاثاء", if (language == "so") "Talaado" else "Tuesday")
                3 -> DayText("الأربعاء", if (language == "so") "Arbaco" else "Wednesday")
                4 -> DayText("الخميس", if (language == "so") "Khamiis" else "Thursday")
                5 -> DayText("الجمعة", if (language == "so") "Jimco" else "Friday")
                6 -> DayText("السبت", if (language == "so") "Sabti" else "Saturday")
                else -> DayText("الأحد", if (language == "so") "Axad" else "Sunday")
            }
        }
    }
}

data class HijriDate(val day: Int, val month: Int, val year: Int) {
    fun monthName(language: String): String {
        val so = arrayOf("Muxarram","Safar","Rabiicul Awal","Rabiicul Thaani","Jumaadal Ula","Jumaadal Aakhirah","Rajab","Shacbaan","Ramadaan","Shawwaal","Dul-Qacda","Dul-Xijjah")
        val en = arrayOf("Muharram","Safar","Rabi al-Awwal","Rabi al-Thani","Jumada al-Awwal","Jumada al-Thani","Rajab","Sha'ban","Ramadan","Shawwal","Dhu al-Qidah","Dhu al-Hijjah")
        return (if (language == "so") so else en)[month - 1]
    }
}

object HijriMath {
    // Civil/tabular Islamic calendar. It is deterministic and works offline.
    fun fromGregorian(date: LocalDate): HijriDate {
        val jd = gregorianToJd(date.year, date.monthValue, date.dayOfMonth)
        return jdToHijri(jd)
    }

    private fun gregorianToJd(y: Int, m: Int, d: Int): Long {
        var yy = y
        var mm = m
        if (mm <= 2) { yy--; mm += 12 }
        val a = yy / 100
        val b = 2 - a + a / 4
        return (365.25 * (yy + 4716)).toLong() +
            (30.6001 * (mm + 1)).toLong() + d + b - 1524
    }

    private fun jdToHijri(jd: Long): HijriDate {
        val l = jd - 1948440 + 10632
        val n = (l - 1) / 10631
        var ll = l - 10631 * n + 354
        val j = ((10985 - ll) / 5316) * ((50 * ll) / 17719) +
            (ll / 5670) * ((43 * ll) / 15238)
        ll = ll - ((30 - j) / 15) * ((17719 * j) / 50) -
            (j / 16) * ((15238 * j) / 43) + 29
        val m = (24 * ll) / 709
        val d = ll - (709 * m) / 24
        val y = 30 * n + j - 30
        return HijriDate(d.toInt(), m.toInt(), y.toInt())
    }
}
