package com.islamicdays.app.widget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import androidx.compose.ui.unit.dp
import androidx.glance.*
import androidx.glance.action.actionStartActivity
import androidx.glance.appwidget.*
import androidx.glance.appwidget.cornerRadius
import androidx.glance.background
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.islamicdays.app.MainActivity
import com.islamicdays.app.data.DayText
import com.islamicdays.app.data.HijriMath
import com.islamicdays.app.data.SettingsStore
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.ZoneId

class IslamicDaysWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = IslamicDaysWidget()

    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            IslamicDaysWidget().update(context, GlanceId.of(id))
        }
    }
}

class IslamicDaysWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val settings = SettingsStore(context).settings.first()
        provideContent {
            val date = LocalDate.now(ZoneId.of(settings.zoneId))
            val hijri = HijriMath.fromGregorian(date)
            val day = DayText.forDate(date, settings.language)
            val accent = ColorProvider(Color(settings.accent.toULong()))

            val vertical = when (settings.position) {
                "Top" -> Alignment.Vertical.Top
                "Bottom" -> Alignment.Vertical.Bottom
                else -> Alignment.Vertical.CenterVertically
            }

            val horizontal = Alignment.Horizontal.CenterHorizontally
            val titleSize = (23f * settings.scale).sp
            val localSize = (14f * settings.scale).sp
            val dateSize = (11f * settings.scale).sp

            Column(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .background(ColorProvider(android.graphics.Color.WHITE))
                    .cornerRadius(28.dp)
                    .padding(16.dp)
                    .clickable(actionStartActivity<MainActivity>()),
                verticalAlignment = vertical,
                horizontalAlignment = horizontal
            ) {
                Text(
                    text = day.arabic,
                    style = TextStyle(
                        color = accent,
                        fontSize = titleSize,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(GlanceModifier.height(5.dp))
                Text(
                    text = day.local,
                    style = TextStyle(fontSize = localSize, fontWeight = FontWeight.Medium)
                )
                Spacer(GlanceModifier.height(3.dp))
                Text(
                    text = "${hijri.day} ${hijri.monthName(settings.language)} ${hijri.year}",
                    style = TextStyle(
                        color = ColorProvider(android.graphics.Color.DKGRAY),
                        fontSize = dateSize
                    )
                )
            }
        }
    }
}
