package com.islamicdays.app

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.islamicdays.app.data.CalendarMode
import com.islamicdays.app.data.DayText
import com.islamicdays.app.data.HijriDate
import com.islamicdays.app.data.HijriMath
import com.islamicdays.app.data.Settings
import com.islamicdays.app.data.SettingsStore
import com.islamicdays.app.widget.IslamicDaysWidgetReceiver
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IslamicDaysApp() }
    }
}

@Composable
fun IslamicDaysApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { SettingsStore(context) }
    val scope = rememberCoroutineScope()
    val settings by store.settings.collectAsState(initial = Settings())

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF1769E0),
            secondary = Color(0xFF6B4DE6),
            background = Color(0xFFF6F7FB),
            surface = Color.White
        )
    ) {
        Surface(color = Color(0xFFF6F7FB), modifier = Modifier.fillMaxSize()) {
            val today = LocalDate.now(ZoneId.of(settings.zoneId))
            val hijri = HijriMath.fromGregorian(today)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Header(settings)
                HeroDay(settings, today, hijri)
                WeekStrip(settings, today)
                SettingsPanel(settings) { newSettings ->
                    scope.launch { store.save(newSettings) }
                    refreshWidgets(context)
                }
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

@Composable
private fun Header(settings: Settings) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("Islamic Days", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(
                if (settings.language == "so") "Maalmaha Islaamka" else "Arabic Islamic calendar",
                color = Color.Gray,
                fontSize = 13.sp
            )
        }
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF147BEF), Color(0xFF5D49E8)))),
            contentAlignment = Alignment.Center
        ) {
            Text("☪", color = Color.White, fontSize = 24.sp)
        }
    }
}

@Composable
private fun HeroDay(settings: Settings, date: LocalDate, hijri: HijriDate) {
    val day = DayText.forDate(date, settings.language)
    val dateText = when (settings.calendarMode) {
        CalendarMode.HIJRI -> "${hijri.day} ${hijri.monthName(settings.language)} ${hijri.year}"
        CalendarMode.GREGORIAN -> "${date.dayOfMonth} ${date.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${date.year}"
    }

    Card(
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(day.arabic, fontSize = 54.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(day.local, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Text(dateText, color = Color.Gray, fontSize = 15.sp)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DateChip("Hijri", "${hijri.day} ${hijri.monthName(settings.language)}")
                DateChip("Gregorian", "${date.dayOfMonth}/${date.monthValue}/${date.year}")
            }
        }
    }
}

@Composable
private fun DateChip(label: String, value: String) {
    Surface(
        color = Color(0xFFF1F3F9),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
            Text(label, fontSize = 10.sp, color = Color.Gray)
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun WeekStrip(settings: Settings, today: LocalDate) {
    Text(
        if (settings.language == "so") "7-da maalmood" else "7 days",
        fontWeight = FontWeight.Bold,
        fontSize = 17.sp
    )
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        (0..6).forEach { offset ->
            val date = today.plusDays(offset.toLong())
            val h = HijriMath.fromGregorian(date)
            val d = DayText.forDate(date, settings.language)
            val selected = offset == 0
            Surface(
                color = if (selected) Color(0xFF1769E0) else Color.White,
                shape = RoundedCornerShape(19.dp),
                shadowElevation = 1.dp
            ) {
                Column(
                    Modifier
                        .width(88.dp)
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        d.arabic,
                        fontSize = 20.sp,
                        color = if (selected) Color.White else Color(0xFF20242C)
                    )
                    Text(
                        "${date.dayOfMonth}/${date.monthValue}",
                        fontSize = 12.sp,
                        color = if (selected) Color.White.copy(alpha = .85f) else Color.Gray
                    )
                    Text(
                        "${h.day} ${h.monthName(settings.language)}",
                        fontSize = 10.sp,
                        color = if (selected) Color.White.copy(alpha = .85f) else Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsPanel(settings: Settings, onChange: (Settings) -> Unit) {
    var showColors by remember { mutableStateOf(false) }
    var showFonts by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                if (settings.language == "so") "Ikhtiyaarrada" else "Options",
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp
            )
            SettingRow(
                if (settings.language == "so") "Luuqadda" else "Language",
                settings.language.uppercase()
            ) {
                onChange(settings.copy(language = if (settings.language == "so") "en" else "so"))
            }
            SettingRow(
                if (settings.language == "so") "Calendar" else "Calendar",
                settings.calendarMode.name
            ) {
                onChange(
                    settings.copy(
                        calendarMode = if (settings.calendarMode == CalendarMode.HIJRI)
                            CalendarMode.GREGORIAN else CalendarMode.HIJRI
                    )
                )
            }
            SettingRow(
                if (settings.language == "so") "Wadanka / Timezone" else "Country / Timezone",
                settings.zoneId.substringAfterLast('/').replace('_', ' ')
            ) {
                val zones = listOf(
                    "Africa/Mogadishu", "Asia/Riyadh", "Asia/Dubai",
                    "Africa/Cairo", "Europe/London", "Europe/Istanbul",
                    "Asia/Kuala_Lumpur", "Asia/Jakarta", "America/New_York"
                )
                val next = zones[(zones.indexOf(settings.zoneId) + 1) % zones.size]
                onChange(settings.copy(zoneId = next))
            }
            SettingRow(
                if (settings.language == "so") "Booska" else "Position",
                settings.position
            ) {
                val p = listOf("Center", "Top", "Bottom")
                onChange(settings.copy(position = p[(p.indexOf(settings.position) + 1) % p.size]))
            }
            SettingRow(
                if (settings.language == "so") "Cabbirka" else "Size",
                "${(settings.scale * 100).toInt()}%"
            ) {
                val s = listOf(.85f, 1f, 1.15f, 1.3f)
                onChange(settings.copy(scale = s[(s.indexOf(settings.scale) + 1) % s.size]))
            }
            SettingRow(
                if (settings.language == "so") "Midab" else "Colors",
                settings.colorName
            ) {
                showColors = !showColors
            }
            if (showColors) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    listOf(
                        "Blue" to 0xFF1769E0, "Purple" to 0xFF6B4DE6, "Black" to 0xFF16181D,
                        "Green" to 0xFF16825D, "Gold" to 0xFFB88317, "Red" to 0xFFC53A3A
                    ).forEach { (name, value) ->
                        Box(
                            Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(value))
                                .clickable {
                                    onChange(settings.copy(colorName = name, accent = value.toLong()))
                                }
                        )
                    }
                }
            }
            SettingRow(
                if (settings.language == "so") "Font" else "Font",
                settings.fontName
            ) {
                showFonts = !showFonts
            }
            if (showFonts) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "Default", "Serif", "Sans", "Monospace",
                        "Naskh", "Amiri", "Kufi", "Thuluth"
                    ).forEach { f ->
                        Text(
                            f,
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onChange(settings.copy(fontName = f)) }
                                .padding(12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingRow(label: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFFF7F8FC))
            .clickable(onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontWeight = FontWeight.Medium)
        Text(value, color = Color(0xFF1769E0), fontSize = 13.sp)
    }
}

private fun refreshWidgets(context: android.content.Context) {
    val manager = AppWidgetManager.getInstance(context)
    val component = ComponentName(context, IslamicDaysWidgetReceiver::class.java)
    manager.getAppWidgetIds(component).forEach {
        IslamicDaysWidgetReceiver.update(context, manager, it)
    }
}
