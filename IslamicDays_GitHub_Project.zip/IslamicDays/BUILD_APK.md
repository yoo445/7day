# Build the APK

## Android Studio

Open `IslamicDays/` in Android Studio and let it sync.

If Android Studio asks to create/update the Gradle wrapper, accept it.

Then:
- Build > Make Project
- Build > Build Bundle(s) / APK(s) > Build APK(s)

## Command line

After a Gradle wrapper has been generated:

```bash
./gradlew assembleDebug
```

Output:
`app/build/outputs/apk/debug/app-debug.apk`

For Play Store:
`./gradlew bundleRelease`
and use Play App Signing.

## GitHub

Create an empty GitHub repository, then:

```bash
git init
git add .
git commit -m "Initial Islamic Days app"
git branch -M main
git remote add origin YOUR_REPO_URL
git push -u origin main
```

The included GitHub Actions workflow will build the debug APK and expose it under the workflow run's Artifacts.
