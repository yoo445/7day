# Islamic Days — Arabic Calligraphy Calendar

A privacy-first Android app for displaying Arabic Islamic weekday/day calligraphy, Hijri and Gregorian dates, a 7-day calendar view, and a configurable home-screen widget.

## Features

- Arabic calligraphy for the seven days:
  - الأحد
  - الإثنين
  - الثلاثاء
  - الأربعاء
  - الخميس
  - الجمعة
  - السبت
- Current Hijri + Gregorian date
- 7-day upcoming view
- Hijri or Gregorian calendar mode
- Country/region timezone selection (Somalia, Saudi Arabia, UAE, Egypt, UK, Turkey, Malaysia, Indonesia, USA)
- Somali and English UI
- Widget with 2×2, 4×2 and flexible resize support
- Widget configuration: position/alignment, size scale, colors, language and timezone
- Large color palette and font selection
- User-selected fonts bundled locally
- Offline-first: no network permission required
- App icon uses the supplied Islamic calendar logo
- Material 3 / iOS-26-inspired rounded, soft UI
- No ads, trackers, or account requirement in this starter
- GitHub Actions workflow builds a signed-ready release artifact

## Important date note

The included Hijri converter uses a deterministic civil/tabular Islamic calendar algorithm. Official moon-sighting or country-specific Umm al-Qura dates can differ by a day. The app architecture keeps date calculation local so a future country-specific calendar provider can be added without changing the widget UI.

## Build locally

1. Install Android Studio with Android SDK and JDK 17.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Build:
   - Debug APK: `./gradlew assembleDebug`
   - Release APK: `./gradlew assembleRelease`

The release APK will be under `app/build/outputs/apk/release/`.

## GitHub Actions

Push this repository to GitHub. The workflow in `.github/workflows/build.yml` builds the debug APK and uploads it as an Actions artifact.

For Google Play, create/use your own signing key and configure Play App Signing. Never commit a private keystore or passwords.

## Security / Play Protect

No app can honestly guarantee that Play Protect will never flag a future build. This project avoids suspicious behavior, requests no dangerous permissions, contains no executable downloader, and uses standard Android components. For distribution, build a release version and sign it with your own legitimate certificate.

## License

Starter project generated for the requester. Replace/add a license before public redistribution.
