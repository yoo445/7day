package com.khad.day

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class DayWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { ids.forEach { update(c, m, it) } }
    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: android.os.Bundle) = update(c, m, id)
    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action != AppWidgetManager.ACTION_APPWIDGET_UPDATE) {
            val m = AppWidgetManager.getInstance(c)
            m.getAppWidgetIds(android.content.ComponentName(c, DayWidget::class.java)).forEach { update(c, m, it) }
        }
    }
    companion object {
        fun update(c: Context, m: AppWidgetManager, id: Int) {
            val d = c.resources.displayMetrics.density
            val o = m.getAppWidgetOptions(id)
            val w = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250) * d).toInt().coerceIn(200, 900)
            val h = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110) * d).toInt().coerceIn(100, 600)
            val v = RemoteViews(c.packageName, R.layout.widget)
            v.setImageViewBitmap(R.id.img, Render.bitmap(c, w, h))
            v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0,
                Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            m.updateAppWidget(id, v)
        }
        fun refreshAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            m.getAppWidgetIds(android.content.ComponentName(c, DayWidget::class.java)).forEach { update(c, m, it) }
        }
    }
}
