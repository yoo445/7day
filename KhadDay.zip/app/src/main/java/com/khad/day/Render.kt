package com.khad.day

import android.content.Context
import android.graphics.*
import android.icu.util.IslamicCalendar
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

object Render {
    // index = Calendar.DAY_OF_WEEK (Sun=1 .. Sat=7)
    private val days = intArrayOf(0, R.drawable.d_sun, R.drawable.d_mon, R.drawable.d_tue,
        R.drawable.d_wed, R.drawable.d_thu, R.drawable.d_fri, R.drawable.d_sat)
    private val months = arrayOf("محرم", "صفر", "ربيع الأول", "ربيع الثاني", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة")

    val palette = listOf(
        "Cad (White)" to 0xFFFFFFFF.toInt(), "Madow (Black)" to 0xFF000000.toInt(),
        "Cirro (Grey)" to 0xFF7F9298.toInt(), "Casaan (Red)" to 0xFFD9364A.toInt(),
        "Buluug (Blue)" to 0xFF1E5AA8.toInt(), "Cagaar (Green)" to 0xFF1B7F4B.toInt(),
        "Dahab (Gold)" to 0xFFD4A72C.toInt(), "Aan muuqan (Transparent)" to 0)
    val solid = palette.dropLast(1)

    val countries = listOf(
        "Telefoonka (Auto)" to "", "Soomaaliya" to "Africa/Mogadishu", "Sacuudi Carabiya" to "Asia/Riyadh",
        "Kenya" to "Africa/Nairobi", "Itoobiya" to "Africa/Addis_Ababa", "Jabuuti" to "Africa/Djibouti",
        "Yemen" to "Asia/Aden", "Imaaraadka (UAE)" to "Asia/Dubai", "Qatar" to "Asia/Qatar",
        "Masar (Egypt)" to "Africa/Cairo", "Suudaan" to "Africa/Khartoum", "Turkiga" to "Europe/Istanbul",
        "Ingiriiska (UK)" to "Europe/London", "Sweden" to "Europe/Stockholm", "Norway" to "Europe/Oslo",
        "Netherlands" to "Europe/Amsterdam", "USA (New York)" to "America/New_York",
        "Canada (Toronto)" to "America/Toronto", "Australia (Sydney)" to "Australia/Sydney")

    val calendars = listOf("Hijri", "Milaadi (Gregorian)", "Labadaba (Both)")
    val vpos = listOf("Sare (Top)", "Dhexe (Middle)", "Hoose (Bottom)")
    val hpos = listOf("Bidix (Left)", "Dhexe (Center)", "Midig (Right)")
    val offsets = listOf("-1", "0", "+1")

    private fun sp(c: Context) = c.getSharedPreferences("p", 0)
    fun get(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun put(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()

    private fun dateLines(c: Context, tz: TimeZone): List<String> {
        val cal = Calendar.getInstance(tz)
        val mode = get(c, "cal", 0)
        val out = ArrayList<String>()
        if (mode != 1) {
            val hc = Calendar.getInstance(tz)
            hc.add(Calendar.DAY_OF_MONTH, get(c, "offi", 1) - 1)
            val h = IslamicCalendar()
            h.setCalculationType(IslamicCalendar.CalculationType.ISLAMIC_UMALQURA)
            h.timeZone = android.icu.util.TimeZone.getTimeZone(tz.id)
            h.timeInMillis = hc.timeInMillis
            out.add("${h.get(android.icu.util.Calendar.DAY_OF_MONTH)} ${months[h.get(android.icu.util.Calendar.MONTH)]} ${h.get(android.icu.util.Calendar.YEAR)}")
        }
        if (mode != 0) {
            val f = SimpleDateFormat("d MMMM yyyy", Locale("so"))
            f.timeZone = tz
            out.add(f.format(cal.time))
        }
        return out
    }

    fun bitmap(c: Context, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val bg = palette[get(c, "bg", 2)].second
        if (bg != 0) {
            val r = h * 0.09f
            p.color = bg
            cv.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), r, r, p)
        }
        val tzId = countries[get(c, "country", 0)].second
        val tz = if (tzId.isEmpty()) TimeZone.getDefault() else TimeZone.getTimeZone(tzId)
        val dow = Calendar.getInstance(tz).get(Calendar.DAY_OF_WEEK)
        val lines = dateLines(c, tz)
        val hp = get(c, "hpos", 1)
        val vp = get(c, "vpos", 1)
        val pad = w * 0.05f

        // date text
        val n = lines.size
        val ts = if (n == 2) h * 0.075f else h * 0.085f
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = solid[get(c, "txt", 0)].second; textSize = ts
            textAlign = when (hp) { 0 -> Paint.Align.LEFT; 1 -> Paint.Align.CENTER; else -> Paint.Align.RIGHT }
        }
        val ax = when (hp) { 0 -> pad; 1 -> w / 2f; else -> w - pad }
        val step = ts * 1.3f
        val firstBase = h * 0.94f - (n - 1) * step
        lines.forEachIndexed { i, s -> cv.drawText(s, ax, firstBase + i * step, tp) }

        // candles (Sat=1 ... Fri=7), on the side opposite to the alignment when right-aligned
        if (get(c, "candles", 1) == 1) {
            val cnt = (dow % 7) + 1
            p.color = solid[get(c, "candle", 3)].second
            val cw = h * 0.07f
            for (i in 0 until cnt) {
                val x = if (hp == 2) pad + i * cw * 1.15f else w - pad - (cnt - i) * cw * 1.15f
                val base = h * 0.98f
                val top = base - h * 0.05f
                cv.drawRect(x, top, x + cw, base, p)
                val path = Path().apply {
                    moveTo(x + cw / 2, top - h * 0.17f)
                    quadTo(x + cw * 1.05f, top - h * 0.09f, x + cw, top)
                    lineTo(x, top)
                    quadTo(x - cw * 0.05f, top - h * 0.09f, x + cw / 2, top - h * 0.17f)
                    close()
                }
                cv.drawPath(path, p)
            }
        }

        // calligraphy
        val img = BitmapFactory.decodeResource(c.resources, days[dow])
        val regTop = h * 0.05f
        val regH = (firstBase - ts * 1.1f) - regTop
        val sz = get(c, "size", 75) / 100f
        val s = minOf((w - 2 * pad) * sz / img.width, regH * sz / img.height)
        val iw = img.width * s
        val ih = img.height * s
        val left = when (hp) { 0 -> pad; 1 -> (w - iw) / 2f; else -> w - pad - iw }
        val top = when (vp) { 0 -> regTop; 1 -> regTop + (regH - ih) / 2f; else -> regTop + regH - ih }
        p.colorFilter = PorterDuffColorFilter(solid[get(c, "ink", 0)].second, PorterDuff.Mode.SRC_IN)
        cv.drawBitmap(img, null, RectF(left, top, left + iw, top + ih), p)
        p.colorFilter = null
        return bmp
    }
}
