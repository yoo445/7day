package com.khad.day

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var img: ImageView
    private lateinit var box: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 50, 40, 60) }
        img = ImageView(this).apply { adjustViewBounds = true }
        box.addView(img)

        spin("Wadanka / Country (waqtiga)", Render.countries.map { it.first }, "country", 0)
        spin("Nooca taariikhda / Calendar", Render.calendars, "cal", 0)
        spin("Hijri hagaajin (maalin) / Adjust", Render.offsets, "offi", 1)
        spin("Booska toosan / Vertical position", Render.vpos, "vpos", 1)
        spin("Booska siman / Horizontal position", Render.hpos, "hpos", 1)

        box.addView(label("Cabbirka khadka / Size"))
        box.addView(SeekBar(this).apply {
            max = 70; progress = Render.get(this@MainActivity, "size", 75) - 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    Render.put(this@MainActivity, "size", 30 + p); refresh(false)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { refresh(true) }
            })
        })

        spin("Midabka background", Render.palette.map { it.first }, "bg", 2)
        spin("Midabka khadka / Calligraphy", Render.solid.map { it.first }, "ink", 0)
        spin("Midabka taariikhda / Date text", Render.solid.map { it.first }, "txt", 0)
        spin("Midabka shumaca / Candles", Render.solid.map { it.first }, "candle", 3)

        box.addView(CheckBox(this).apply {
            text = "Muuji shumaca / Show candles"
            isChecked = Render.get(this@MainActivity, "candles", 1) == 1
            setOnCheckedChangeListener { _, on ->
                Render.put(this@MainActivity, "candles", if (on) 1 else 0); refresh(true)
            }
        })
        box.addView(TextView(this).apply {
            text = "Widget: riix home screen → Widgets → Khadka Maalinta."
            gravity = Gravity.CENTER; textSize = 13f; setPadding(0, 40, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(box) })
        refresh(true)
    }

    private fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, 28, 0, 4) }

    private fun spin(title: String, items: List<String>, key: String, def: Int) {
        box.addView(label(title))
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        s.setSelection(Render.get(this, key, def))
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (Render.get(this@MainActivity, key, def) != pos) {
                    Render.put(this@MainActivity, key, pos); refresh(true)
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        box.addView(s)
    }

    private fun refresh(widget: Boolean) {
        img.setImageBitmap(Render.bitmap(this, 900, 600))
        if (widget) DayWidget.refreshAll(this)
    }
}
